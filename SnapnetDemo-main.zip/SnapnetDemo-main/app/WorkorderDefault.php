<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WorkorderDefault extends Model
{
    //
    
    protected $fillable=['header', 'comment'];

}
