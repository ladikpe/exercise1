<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TravelVendor extends Model
{
    //
 	protected $fillable=['region', 'name', 'service', 'email', 'phone', 'address'];
   
}
