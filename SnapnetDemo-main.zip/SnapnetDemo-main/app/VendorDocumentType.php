<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorDocumentType extends Model
{
    //
 	protected $fillable=['name', 'description', 'created_by'];
}
