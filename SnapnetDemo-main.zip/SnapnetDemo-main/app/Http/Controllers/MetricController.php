<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MetricController extends Controller
{
    //
}
